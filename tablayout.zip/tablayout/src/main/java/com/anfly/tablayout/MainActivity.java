package com.anfly.tablayout;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

/**
 * 1.创建布局：viewpager和tablayout，找控件
 * 2.创建fragment
 * 3.创建集合存放fragment
 * 4.创建adapter
 * 5.vp设置adapter
 * 6.vp和tab关联起来
 * 7.给tab设置title
 */
public class MainActivity extends AppCompatActivity {

    private TabLayout tab;
    private ViewPager vp;
    private ArrayList<Fragment> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        tab = (TabLayout) findViewById(R.id.tab);
        vp = (ViewPager) findViewById(R.id.vp);

        list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            PageFragment fragment = new PageFragment("fragment" + i);
            list.add(fragment);
        }

        FragmentAdapter adapter = new FragmentAdapter(getSupportFragmentManager(), list);
        vp.setAdapter(adapter);

        tab.setupWithViewPager(vp);

        //动态添加tab
        tab.getTabAt(0).setText("TAB1");
        tab.getTabAt(1).setText("TAB2");
        tab.getTabAt(2).setText("TAB3");

    }
}
