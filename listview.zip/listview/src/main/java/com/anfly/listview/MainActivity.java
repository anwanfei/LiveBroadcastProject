package com.anfly.listview;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * 手动加载更多
 * 1.使用Listview显示网络数据列表
 * 2.给Listview添加一个脚布局并找到脚布局的控件
 * 3.设置控件的点击事件，再加载一次数据
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ListView lv;
    private String foodUrl = "http://www.qubaobei.com/ios/cf/dish_list.php?stage_id=1&limit=20&page=1";
    private ArrayList<FoodBean.DataBean> list;
    private FoodAdapter foodAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
    }

    private void initData() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(foodUrl);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    int responseCode = con.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        InputStream inputStream = con.getInputStream();
                        String json = streamToString(inputStream);
                        final FoodBean foodBean = new Gson().fromJson(json, FoodBean.class);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                List<FoodBean.DataBean> data = foodBean.getData();
                                list.addAll(data);
                                foodAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private String streamToString(InputStream inputStream) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        int length = -1;
        byte[] bytes = new byte[1024];
        try {
            while ((length = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, length);
            }

            outputStream.close();
            String result = outputStream.toString();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private void initView() {
        lv = (ListView) findViewById(R.id.lv);

        //添加脚布局
        View view = LayoutInflater.from(this).inflate(R.layout.view_foot, null);
        lv.addFooterView(view);
        view.findViewById(R.id.btn_more).setOnClickListener(this);

        list = new ArrayList<>();
        foodAdapter = new FoodAdapter(this, list);

        lv.setAdapter(foodAdapter);
    }

    @Override
    public void onClick(View v) {
        initData();
    }
}
